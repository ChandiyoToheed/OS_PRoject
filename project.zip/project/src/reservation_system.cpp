// src/reservation_system.cpp
#include "reservation_system.h"
#include "ui_utils.h"
#include <iostream>
#include <cstdlib>
#include <chrono>
#include <random>

ReservationSystem::ReservationSystem(int flight_count, int seats_per_flight) {
    // Create flights with more descriptive names
    flights.emplace_back(std::make_unique<Flight>("Flight 101 - New York to Los Angeles", seats_per_flight));
    flights.emplace_back(std::make_unique<Flight>("Flight 102 - New York to Miami", seats_per_flight));
    flights.emplace_back(std::make_unique<Flight>("Flight 103 - Chicago to Miami", seats_per_flight));
    
    // If more flights are needed beyond the predefined ones
    for (int i = 3; i < flight_count; ++i) {
        flights.emplace_back(std::make_unique<Flight>("Flight " + std::to_string(104+i-3), seats_per_flight));
    }
    
    // Initialize semaphores for each flight
    for (int i = 0; i < flights.size(); ++i) {
        semaphores.emplace_back(std::make_unique<Semaphore>(seats_per_flight));
    }
}

void ReservationSystem::simulate(int user_threads) {
    for (int i = 0; i < user_threads; ++i) {
        threads.emplace_back(&ReservationSystem::booking_worker, this, i);
    }
    for (auto& t : threads) {
        if (t.joinable()) t.join();
    }
}

void ReservationSystem::bookTicket() {
    UIUtils::displayBoxedText("Available Flights");
    std::cout << std::endl;
    
    for (size_t i = 0; i < flights.size(); ++i) {
        std::string flight_info = std::to_string(i + 1) + ". " + flights[i]->get_flight_id() +
                                " - " + std::to_string(flights[i]->available_seats()) + " seats available";
        
        // Color the flight info based on available seats
        if (flights[i]->available_seats() == 0) {
            std::cout << UIUtils::colorText(flight_info, UIUtils::COLOR_RED) << std::endl;
        } else if (flights[i]->available_seats() < 3) {
            std::cout << UIUtils::colorText(flight_info, UIUtils::COLOR_YELLOW) << std::endl;
        } else {
            std::cout << UIUtils::colorText(flight_info, UIUtils::COLOR_GREEN) << std::endl;
        }
    }
    std::cout << std::endl;

    int flight_choice, ticket_count;
    std::cout << UIUtils::colorText("Select a flight by entering the number: ", UIUtils::COLOR_CYAN);
    std::cin >> flight_choice;

    if (flight_choice < 1 || flight_choice > flights.size()) {
        std::cout << UIUtils::colorText("Invalid flight selection. Please choose a valid flight.", UIUtils::COLOR_RED) << std::endl;
        return;
    }

    std::cout << UIUtils::colorText("Enter number of tickets: ", UIUtils::COLOR_CYAN);
    std::cin >> ticket_count;

    // Show booking animation
    std::cout << UIUtils::colorText("Processing booking request...", UIUtils::COLOR_YELLOW) << std::endl;
    UIUtils::showLoadingAnimation(1500);
    
    int booked_seat;
    bool all_booked = true;
    
    for (int i = 0; i < ticket_count; ++i) {
        if (!flights[flight_choice - 1]->book_seat(booked_seat)) {
            std::cout << UIUtils::colorText("Not enough seats available. Booking stopped.", UIUtils::COLOR_RED) << std::endl;
            all_booked = false;
            break;
        }
        // Show short animation for each booked seat
        UIUtils::showLoadingAnimation(200);
    }

    if (all_booked) {
        std::string success_msg = std::to_string(ticket_count) + " tickets successfully booked on " + 
                                flights[flight_choice - 1]->get_flight_id();
        std::cout << UIUtils::colorText(success_msg, UIUtils::COLOR_GREEN) << std::endl;
        
        // Show seat numbers animation
        std::cout << UIUtils::colorText("Generating boarding passes...", UIUtils::COLOR_CYAN) << std::endl;
        UIUtils::showLoadingAnimation(1000);
        
        std::cout << UIUtils::colorText("Your booking is confirmed! Enjoy your flight!", UIUtils::COLOR_GREEN) << std::endl;
    }
}

void ReservationSystem::viewAvailableFlights() {
    UIUtils::typeText(UIUtils::colorText("Loading flight information...", UIUtils::COLOR_CYAN), 20);
    UIUtils::showLoadingAnimation(800);
    
    std::cout << std::endl;
    std::cout << UIUtils::colorText("╔═══════════════════════════════════════════════════════╗", UIUtils::COLOR_BLUE) << std::endl;
    std::cout << UIUtils::colorText("║               AVAILABLE FLIGHTS                       ║", UIUtils::COLOR_BLUE) << std::endl;
    std::cout << UIUtils::colorText("╠═══════════════════════════════════════════════════════╣", UIUtils::COLOR_BLUE) << std::endl;
    
    for (const auto& flight : flights) {
        std::string flight_info = "║  " + flight->get_flight_id() + 
                               " - " + std::to_string(flight->available_seats()) + " seats available";
        
        // Pad with spaces to align the right border
        while (flight_info.length() < 55) {
            flight_info += " ";
        }
        flight_info += "║";
        
        // Color the flight info based on available seats
        if (flight->available_seats() == 0) {
            std::cout << UIUtils::colorText(flight_info, UIUtils::COLOR_RED) << std::endl;
        } else if (flight->available_seats() < 3) {
            std::cout << UIUtils::colorText(flight_info, UIUtils::COLOR_YELLOW) << std::endl;
        } else {
            std::cout << UIUtils::colorText(flight_info, UIUtils::COLOR_GREEN) << std::endl;
        }
    }
    
    std::cout << UIUtils::colorText("╚═══════════════════════════════════════════════════════╝", UIUtils::COLOR_BLUE) << std::endl;
}

void ReservationSystem::cancelTicket() {
    UIUtils::displayBoxedText("CANCEL BOOKING");
    std::string flight_id;

    std::cout << UIUtils::colorText("Enter your booking ID or the flight number: ", UIUtils::COLOR_CYAN);
    std::cin >> flight_id;

    // Show searching animation
    std::cout << UIUtils::colorText("Searching for your booking...", UIUtils::COLOR_YELLOW) << std::endl;
    UIUtils::showLoadingAnimation(1000);
    
    // Find the flight
    bool found = false;
    for (const auto& flight : flights) {
        if (flight->get_flight_id().find(flight_id) != std::string::npos) {
            found = true;
            std::cout << UIUtils::colorText("Found booking on: " + flight->get_flight_id(), UIUtils::COLOR_GREEN) << std::endl;
            std::cout << UIUtils::colorText("Are you sure you want to cancel your booking? (y/n): ", UIUtils::COLOR_YELLOW);
            char confirm;
            std::cin >> confirm;
            
            if (confirm == 'y' || confirm == 'Y') {
                // Animation for cancellation processing
                std::cout << UIUtils::colorText("Processing cancellation...", UIUtils::COLOR_YELLOW) << std::endl;
                UIUtils::showLoadingAnimation(1200);
                
                // Since we don't track individual bookings by user, we'll cancel the most recently booked seat
                int seat_number = flight->get_most_recent_booked_seat();
                if (seat_number >= 0 && flight->cancel_seat(seat_number)) {
                    std::cout << UIUtils::colorText("Your booking on " + flight->get_flight_id() + 
                                               " has been successfully cancelled.", UIUtils::COLOR_GREEN) << std::endl;
                    std::cout << UIUtils::colorText("Remaining seats on " + flight->get_flight_id() + 
                                               ": " + std::to_string(flight->available_seats()), UIUtils::COLOR_BLUE) << std::endl;
                    
                    // Signal the semaphore to indicate a seat is available
                    for (size_t i = 0; i < flights.size(); ++i) {
                        if (flights[i]->get_flight_id() == flight->get_flight_id()) {
                            semaphores[i]->signal();
                            break;
                        }
                    }
                    return;
                } else {
                    std::cout << UIUtils::colorText("No bookings found to cancel on this flight.", UIUtils::COLOR_RED) << std::endl;
                    return;
                }
            } else {
                std::cout << UIUtils::colorText("Cancellation aborted.", UIUtils::COLOR_YELLOW) << std::endl;
                return;
            }
        }
    }

    if (!found) {
        std::cout << UIUtils::colorText("No booking found for " + flight_id + 
                                   ". Please check your booking ID and try again.", UIUtils::COLOR_RED) << std::endl;
    }
}

void ReservationSystem::rebookTicket() {
    UIUtils::displayBoxedText("REBOOK TICKET");
    std::string old_flight_id;
    int new_flight_choice, ticket_count;

    std::cout << UIUtils::colorText("Enter your previous flight ID: ", UIUtils::COLOR_CYAN);
    std::cin >> old_flight_id;

    // Show verification animation
    std::cout << UIUtils::colorText("Verifying previous booking...", UIUtils::COLOR_YELLOW) << std::endl;
    UIUtils::showLoadingAnimation(1000);
    
    std::cout << UIUtils::colorText("Available Flights for Rebooking:", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << std::endl;
    
    for (size_t i = 0; i < flights.size(); ++i) {
        std::string flight_info = std::to_string(i + 1) + ". " + flights[i]->get_flight_id() +
                                " - " + std::to_string(flights[i]->available_seats()) + " seats available";
        
        // Color the flight info based on available seats
        if (flights[i]->available_seats() == 0) {
            std::cout << UIUtils::colorText(flight_info, UIUtils::COLOR_RED) << std::endl;
        } else if (flights[i]->available_seats() < 3) {
            std::cout << UIUtils::colorText(flight_info, UIUtils::COLOR_YELLOW) << std::endl;
        } else {
            std::cout << UIUtils::colorText(flight_info, UIUtils::COLOR_GREEN) << std::endl;
        }
    }
    std::cout << std::endl;

    std::cout << UIUtils::colorText("Select a new flight by entering the number: ", UIUtils::COLOR_CYAN);
    std::cin >> new_flight_choice;

    if (new_flight_choice < 1 || new_flight_choice > flights.size()) {
        std::cout << UIUtils::colorText("Invalid flight selection. Please choose a valid flight.", UIUtils::COLOR_RED) << std::endl;
        return;
    }

    std::cout << UIUtils::colorText("Enter number of tickets: ", UIUtils::COLOR_CYAN);
    std::cin >> ticket_count;

    // Show rebooking animation
    std::cout << UIUtils::colorText("Processing rebooking request...", UIUtils::COLOR_YELLOW) << std::endl;
    UIUtils::showLoadingAnimation(1500);
    
    int booked_seat;
    bool all_booked = true;
    
    for (int i = 0; i < ticket_count; ++i) {
        if (!flights[new_flight_choice - 1]->book_seat(booked_seat)) {
            std::cout << UIUtils::colorText("Not enough seats available. Rebooking stopped.", UIUtils::COLOR_RED) << std::endl;
            all_booked = false;
            break;
        }
        // Show short animation for each booked seat
        UIUtils::showLoadingAnimation(200);
    }

    if (all_booked) {
        std::string success_msg = std::to_string(ticket_count) + " tickets successfully rebooked on " + 
                                flights[new_flight_choice - 1]->get_flight_id();
        std::cout << UIUtils::colorText(success_msg, UIUtils::COLOR_GREEN) << std::endl;
        
        // Show seat numbers animation
        std::cout << UIUtils::colorText("Generating new boarding passes...", UIUtils::COLOR_CYAN) << std::endl;
        UIUtils::showLoadingAnimation(1000);
        
        std::cout << UIUtils::colorText("Your rebooking is confirmed! Enjoy your flight!", UIUtils::COLOR_GREEN) << std::endl;
    }
}

void ReservationSystem::booking_worker(int thread_id) {
    std::default_random_engine gen(std::random_device{}());
    std::uniform_int_distribution<int> flight_dist(0, flights.size() - 1);
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    for (int i = 0; i < 5; ++i) {
        int flight_index = flight_dist(gen);
        semaphores[flight_index]->wait();
        int seat = -1;
        if (flights[flight_index]->book_seat(seat)) {
            std::cout << "Thread " << thread_id << " booked seat " << seat << " on " << flights[flight_index]->get_flight_id() << "\n";
        } else {
            std::cout << "Thread " << thread_id << " failed to book on " << flights[flight_index]->get_flight_id() << "\n";
        }
        semaphores[flight_index]->signal();
    }
}
