
// src/logger.cpp
#include "logger.h"

std::mutex Logger::log_mutex;

void Logger::log(const std::string& message) {
    std::lock_guard<std::mutex> lock(log_mutex);
    std::cout << message << std::endl;
}
