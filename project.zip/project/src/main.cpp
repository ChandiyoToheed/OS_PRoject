// src/main.cpp
#include "reservation_system.h"
#include "ui_utils.h"
#include <iostream>
#include <unordered_map>
#include <limits>

// Add a mock user database
std::unordered_map<std::string, std::string> user_db = {
    {"Ali_bhelar", "password123"},
    {"Toheed", "pass1234"}
};

bool authenticateUser() {
    UIUtils::clearScreen();
    UIUtils::displayLogo();
    UIUtils::displayAirplane();
    
    std::string username, password;
    UIUtils::typeText(UIUtils::colorText("Welcome to Flight Guy Reservation System", UIUtils::COLOR_CYAN), 20);
    std::cout << std::endl;
    
    std::cout << UIUtils::colorText("Enter Username: ", UIUtils::COLOR_YELLOW);
    std::cin >> username;
    std::cout << UIUtils::colorText("Enter Password: ", UIUtils::COLOR_YELLOW);
    std::cin >> password;

    // Show loading animation while "verifying" credentials
    UIUtils::showLoadingAnimation(1500);
    
    if (user_db.find(username) != user_db.end() && user_db[username] == password) {
        UIUtils::clearScreen();
        UIUtils::displayLogo();
        std::string welcome_msg = "Welcome, " + username + "!";
        UIUtils::displayBoxedText(welcome_msg);
        UIUtils::waitForEnter();
        return true;
    } else {
        UIUtils::clearScreen();
        std::cout << UIUtils::colorText("Invalid username or password. Please try again.", UIUtils::COLOR_RED) << std::endl;
        UIUtils::waitForEnter();
        return false;
    }
}

void simulateReservation() {
    UIUtils::clearScreen();
    UIUtils::typeText(UIUtils::colorText("Starting reservation simulation with multiple users...", UIUtils::COLOR_CYAN));
    
    const int user_threads = 10;
    ReservationSystem system(3, 5);
    
    UIUtils::showLoadingAnimation(2000);
    system.simulate(user_threads);
    
    UIUtils::displayBoxedText("Simulation completed successfully!");
    UIUtils::waitForEnter();
}

void displayMenu() {
    UIUtils::clearScreen();
    UIUtils::displayLogo();
    
    std::cout << UIUtils::colorText("╔══════════════════════════════════╗", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║           MAIN MENU              ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("╠══════════════════════════════════╣", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║ ", UIUtils::COLOR_CYAN) << UIUtils::colorText("1. Book a ticket", UIUtils::COLOR_GREEN) << UIUtils::colorText("                ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║ ", UIUtils::COLOR_CYAN) << UIUtils::colorText("2. Cancel a booking", UIUtils::COLOR_RED) << UIUtils::colorText("             ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║ ", UIUtils::COLOR_CYAN) << UIUtils::colorText("3. Rebook a ticket", UIUtils::COLOR_YELLOW) << UIUtils::colorText("              ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║ ", UIUtils::COLOR_CYAN) << UIUtils::colorText("4. View available flights", UIUtils::COLOR_BLUE) << UIUtils::colorText("        ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║ ", UIUtils::COLOR_CYAN) << UIUtils::colorText("5. Logout", UIUtils::COLOR_MAGENTA) << UIUtils::colorText("                     ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║ ", UIUtils::COLOR_CYAN) << UIUtils::colorText("6. Help", UIUtils::COLOR_WHITE) << UIUtils::colorText("                       ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║ ", UIUtils::COLOR_CYAN) << UIUtils::colorText("7. Simulate race condition", UIUtils::COLOR_CYAN) << UIUtils::colorText("      ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("╚══════════════════════════════════╝", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << std::endl;
    std::cout << UIUtils::colorText("Enter your choice: ", UIUtils::COLOR_YELLOW);
}

void displayHelp() {
    UIUtils::clearScreen();
    UIUtils::displayBoxedText("HELP SECTION");
    
    std::cout << UIUtils::colorText("╔══════════════════════════════════════════════════════════════╗", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║ ", UIUtils::COLOR_CYAN) << UIUtils::colorText("1. Book a ticket: ", UIUtils::COLOR_GREEN) << UIUtils::colorText("Reserve a seat on a flight.              ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║ ", UIUtils::COLOR_CYAN) << UIUtils::colorText("2. Cancel a booking: ", UIUtils::COLOR_RED) << UIUtils::colorText("Cancel an existing reservation.      ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║ ", UIUtils::COLOR_CYAN) << UIUtils::colorText("3. Rebook a ticket: ", UIUtils::COLOR_YELLOW) << UIUtils::colorText("Change your booking to another flight. ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║ ", UIUtils::COLOR_CYAN) << UIUtils::colorText("4. View available flights: ", UIUtils::COLOR_BLUE) << UIUtils::colorText("See available flights and seats. ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║ ", UIUtils::COLOR_CYAN) << UIUtils::colorText("5. Logout: ", UIUtils::COLOR_MAGENTA) << UIUtils::colorText("Exit the system.                            ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║ ", UIUtils::COLOR_CYAN) << UIUtils::colorText("6. Help: ", UIUtils::COLOR_WHITE) << UIUtils::colorText("Display this help section.                   ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("║ ", UIUtils::COLOR_CYAN) << UIUtils::colorText("7. Simulate race condition: ", UIUtils::COLOR_CYAN) << UIUtils::colorText("Test concurrency handling.    ║", UIUtils::COLOR_CYAN) << std::endl;
    std::cout << UIUtils::colorText("╚══════════════════════════════════════════════════════════════╝", UIUtils::COLOR_CYAN) << std::endl;
    
    UIUtils::waitForEnter();
}

void simulateRaceCondition() {
    UIUtils::clearScreen();
    UIUtils::typeText(UIUtils::colorText("Simulating race condition with multiple users booking tickets...", UIUtils::COLOR_CYAN));
    
    ReservationSystem system(1, 5);  // Create a system with 1 flight that has 5 seats
    
    UIUtils::showLoadingAnimation(500);
    UIUtils::typeText(UIUtils::colorText("\nUser A: Booking 5 tickets on Flight 101...", UIUtils::COLOR_YELLOW));
    
    // User A books 5 tickets (all available seats)
    int flight_choice = 1;
    int ticket_count = 5;
    int booked_seat;
    bool success = true;
    
    for (int i = 0; i < ticket_count && success; ++i) {
        success = system.getFlights()[flight_choice - 1]->book_seat(booked_seat);
        UIUtils::showLoadingAnimation(300);
    }
    
    if (success) {
        UIUtils::typeText(UIUtils::colorText("User A: 5 tickets successfully booked on Flight 101.", UIUtils::COLOR_GREEN));
    }
    
    // User B tries to book 3 tickets but will be blocked by the semaphore
    UIUtils::typeText(UIUtils::colorText("\nUser B: Booking 3 tickets on Flight 101...", UIUtils::COLOR_YELLOW));
    UIUtils::typeText(UIUtils::colorText("User B: Waiting for seats to become available...", UIUtils::COLOR_RED));
    
    // Simulate User A cancelling their booking
    UIUtils::showLoadingAnimation(1000);
    UIUtils::typeText(UIUtils::colorText("\nUser A: Cancelling 5 tickets on Flight 101...", UIUtils::COLOR_YELLOW));
    
    // We need to get and cancel each seat individually
    for (int i = 0; i < 5; ++i) {
        int seat = system.getFlights()[flight_choice - 1]->get_most_recent_booked_seat();
        if (seat >= 0) {
            system.getFlights()[flight_choice - 1]->cancel_seat(seat);
            UIUtils::showLoadingAnimation(300);
        }
    }
    
    // Now User B can book tickets
    UIUtils::typeText(UIUtils::colorText("\nSeats now available! User B continuing booking...", UIUtils::COLOR_GREEN));
    success = true;
    for (int i = 0; i < 3 && success; ++i) {
        success = system.getFlights()[flight_choice - 1]->book_seat(booked_seat);
        UIUtils::showLoadingAnimation(300);
    }
    
    if (success) {
        UIUtils::typeText(UIUtils::colorText("User B: 3 tickets successfully booked on Flight 101.", UIUtils::COLOR_GREEN));
    }
    
    UIUtils::displayBoxedText("Race condition simulation completed");
    UIUtils::waitForEnter();
}

int main() {
    // Try authentication up to 3 times
    int loginAttempts = 0;
    bool authenticated = false;
    
    while (loginAttempts < 3 && !authenticated) {
        authenticated = authenticateUser();
        if (!authenticated) loginAttempts++;
        
        if (loginAttempts == 3 && !authenticated) {
            UIUtils::clearScreen();
            UIUtils::typeText(UIUtils::colorText("Too many failed login attempts. Exiting program.", UIUtils::COLOR_RED));
            UIUtils::waitForEnter();
            return 0;
        }
    }

    ReservationSystem system(3, 10);

    while (true) {
        displayMenu();
        int choice;
        std::cin >> choice;
        
        // Clear any error state and handle invalid input
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            choice = 0; // Invalid choice
        }

        switch (choice) {
            case 1:
                UIUtils::clearScreen();
                system.bookTicket();
                UIUtils::displayBookingSuccess();
                UIUtils::waitForEnter();
                break;
            case 2:
                UIUtils::clearScreen();
                system.cancelTicket();
                UIUtils::displayBookingCancelled();
                UIUtils::waitForEnter();
                break;
            case 3:
                UIUtils::clearScreen();
                system.rebookTicket();
                UIUtils::waitForEnter();
                break;
            case 4:
                UIUtils::clearScreen();
                UIUtils::displayBoxedText("Available Flights");
                system.viewAvailableFlights();
                UIUtils::displayAirplane();
                UIUtils::waitForEnter();
                break;
            case 5:
                UIUtils::clearScreen();
                UIUtils::typeText(UIUtils::colorText("Logging out...", UIUtils::COLOR_YELLOW));
                UIUtils::showLoadingAnimation(1000);
                UIUtils::clearScreen();
                UIUtils::typeText(UIUtils::colorText("You have successfully logged out. Goodbye!", UIUtils::COLOR_GREEN));
                UIUtils::waitForEnter();
                return 0;
            case 6:
                displayHelp();
                break;
            case 7:
                simulateRaceCondition();
                break;
            default:
                UIUtils::clearScreen();
                UIUtils::typeText(UIUtils::colorText("Invalid choice. Please try again.", UIUtils::COLOR_RED));
                UIUtils::waitForEnter();
        }
    }

    return 0;
}
