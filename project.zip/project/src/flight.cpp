// src/flight.cpp
#include "flight.h"
#include <algorithm>
#include <set>

Flight::Flight(const std::string& flight_id, int seat_count)
    : flight_id(flight_id), seats(seat_count, false) {}

bool Flight::book_seat(int& seat_number) {
    std::lock_guard<std::mutex> lock(seat_mutex);
    for (size_t i = 0; i < seats.size(); ++i) {
        if (!seats[i]) {
            seats[i] = true;
            seat_number = static_cast<int>(i);
            active_bookings.insert(seat_number);  // Track this booking
            return true;
        }
    }
    return false;
}

bool Flight::cancel_seat(int seat_number) {
    std::lock_guard<std::mutex> lock(seat_mutex);
    if (seat_number >= 0 && static_cast<size_t>(seat_number) < seats.size() && seats[seat_number]) {
        seats[seat_number] = false;
        active_bookings.erase(seat_number);  // Remove from active bookings
        return true;
    }
    return false;
}

int Flight::available_seats() const {
    std::lock_guard<std::mutex> lock(seat_mutex);
    return std::count(seats.begin(), seats.end(), false);
}

std::string Flight::get_flight_id() const {
    return flight_id;
}

int Flight::get_most_recent_booked_seat() {
    std::lock_guard<std::mutex> lock(seat_mutex);
    if (!active_bookings.empty()) {
        // Return the highest seat number (most recently booked)
        int seat = *active_bookings.rbegin();
        active_bookings.erase(seat);  // Remove it so we don't return it again
        return seat;
    }
    return -1;  // No active bookings
}
