#include "ui_utils.h"
#include <iostream>
#include <string>
#include <thread>
#include <chrono>
#include <vector>
#include <cstdlib>

// Initialize color code constants
const std::string UIUtils::COLOR_RESET = "\033[0m";
const std::string UIUtils::COLOR_RED = "\033[31m";
const std::string UIUtils::COLOR_GREEN = "\033[32m";
const std::string UIUtils::COLOR_YELLOW = "\033[33m";
const std::string UIUtils::COLOR_BLUE = "\033[34m";
const std::string UIUtils::COLOR_MAGENTA = "\033[35m";
const std::string UIUtils::COLOR_CYAN = "\033[36m";
const std::string UIUtils::COLOR_WHITE = "\033[37m";

void UIUtils::clearScreen() {
#ifdef _WIN32
    std::system("cls");
#else
    std::system("clear");
#endif
}

void UIUtils::showLoadingAnimation(int milliseconds) {
    const std::vector<std::string> frames = {
        "[    ]", "[=   ]", "[==  ]", "[=== ]", "[====]",
        "[=== ]", "[==  ]", "[=   ]", "[    ]"
    };
    
    int totalFrames = frames.size();
    int iterations = milliseconds / 100;  // Each frame shows for ~100ms
    
    for (int i = 0; i < iterations; ++i) {
        std::cout << "\r" << COLOR_CYAN << frames[i % totalFrames] << COLOR_RESET << " Loading..." << std::flush;
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    std::cout << "\r                      \r" << std::flush;  // Clear the line
}

void UIUtils::typeText(const std::string& text, int delayMilliseconds) {
    for (char c : text) {
        std::cout << c << std::flush;
        std::this_thread::sleep_for(std::chrono::milliseconds(delayMilliseconds));
    }
    std::cout << std::endl;
}

void UIUtils::displayLogo() {
    std::cout << COLOR_CYAN;
    std::cout << "=======================================================" << std::endl;
    std::cout << "   ______ _ _       _     _      _____           " << std::endl;
    std::cout << "  |  ____| (_)     | |   | |    / ____|          " << std::endl;
    std::cout << "  | |__  | |_  __ _| |__ | |_  | |  __ _   _  ___ " << std::endl;
    std::cout << "  |  __| | | |/ _` | '_ \\| __| | | |_ | | | |/ _ \\" << std::endl;
    std::cout << "  | |    | | | (_| | | | | |_  | |__| | |_| |  __/" << std::endl;
    std::cout << "  |_|    |_|_|\\__, |_| |_|\\__|  \\_____|\\__, |\\___|" << std::endl;
    std::cout << "               __/ |                   __/ |     " << std::endl;
    std::cout << "              |___/                   |___/      " << std::endl;
    std::cout << "                                                " << std::endl;
    std::cout << "             Reservation System               " << std::endl;
    std::cout << "=======================================================" << std::endl;
    std::cout << COLOR_RESET << std::endl;
}

void UIUtils::displayAirplane() {
    std::cout << COLOR_BLUE;
    std::cout << "                                  ." << std::endl;
    std::cout << "                                 /|" << std::endl;
    std::cout << "                                / |" << std::endl;
    std::cout << "                               /__|______" << std::endl;
    std::cout << "                      ________/          \\_" << std::endl;
    std::cout << "             _------'                      `--.__" << std::endl;
    std::cout << "            /                                     `-." << std::endl;
    std::cout << "           /                                         \\" << std::endl;
    std::cout << " _________/                           _              `------_" << std::endl;
    std::cout << " \\        |                          / \\                    /" << std::endl;
    std::cout << "  \\       |                        _/   \\                  /" << std::endl;
    std::cout << "   \\      |________________________/      \\________________/" << std::endl;
    std::cout << "    \\                                                    /" << std::endl;
    std::cout << "     \\                                                  /" << std::endl;
    std::cout << "      \\________________________________________________/" << std::endl;
    std::cout << COLOR_RESET << std::endl;
}

void UIUtils::displayBookingSuccess() {
    std::cout << COLOR_GREEN;
    std::cout << "  _____                            _             _ " << std::endl;
    std::cout << " / ____|                          | |           | |" << std::endl;
    std::cout << "| (___  _   _  ___ ___ ___  ___ __| | ___ _   _| |" << std::endl;
    std::cout << " \\___ \\| | | |/ __/ __/ _ \\/ __/ _` |/ _ \\ | | | |" << std::endl;
    std::cout << " ____) | |_| | (_| (_|  __/ (_| (_| |  __/ |_| |_|" << std::endl;
    std::cout << "|_____/ \\__,_|\\___\\___\\___|\\___\\__,_|\\___|\\__, (_)" << std::endl;
    std::cout << "                                           __/ |  " << std::endl;
    std::cout << "                                          |___/   " << std::endl;
    std::cout << COLOR_RESET << std::endl;
}

void UIUtils::displayBookingCancelled() {
    std::cout << COLOR_RED;
    std::cout << "  ____              _    _                 _____                      _ _          _ " << std::endl;
    std::cout << " |  _ \\            | |  (_)               / ____|                    | | |        | |" << std::endl;
    std::cout << " | |_) | ___   ___ | | ___ _ __   __ _   | |     __ _ _ __   ___ ___| | | ___  __| |" << std::endl;
    std::cout << " |  _ < / _ \\ / _ \\| |/ / | '_ \\ / _` |  | |    / _` | '_ \\ / __/ _ \\ | |/ _ \\/ _` |" << std::endl;
    std::cout << " | |_) | (_) | (_) |   <| | | | | (_| |  | |___| (_| | | | | (_|  __/ | |  __/ (_| |" << std::endl;
    std::cout << " |____/ \\___/ \\___/|_|\\_\\_|_| |_|\\__, |   \\_____\\__,_|_| |_|\\___\\___|_|_|\\___|\\__,_|" << std::endl;
    std::cout << "                                  __/ |                                              " << std::endl;
    std::cout << "                                 |___/                                               " << std::endl;
    std::cout << COLOR_RESET << std::endl;
}

std::string UIUtils::colorText(const std::string& text, const std::string& colorCode) {
    return colorCode + text + COLOR_RESET;
}

void UIUtils::displayBoxedText(const std::string& text) {
    int textLength = text.length();
    std::string border(textLength + 4, '=');
    
    std::cout << "+" << border << "+" << std::endl;
    std::cout << "|  " << text << "  |" << std::endl;
    std::cout << "+" << border << "+" << std::endl;
}

void UIUtils::waitForEnter(const std::string& message) {
    std::cout << COLOR_YELLOW << message << COLOR_RESET;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::cin.get();
}