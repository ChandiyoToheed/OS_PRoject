// src/semaphore_wrapper.cpp
#include "semaphore_wrapper.h"

Semaphore::Semaphore(unsigned int initial_count) {
    if (sem_init(&sem, 0, initial_count) != 0) {
        throw std::runtime_error("Failed to initialize semaphore");
    }
}

Semaphore::~Semaphore() {
    sem_destroy(&sem);
}

void Semaphore::wait() {
    sem_wait(&sem);
}

void Semaphore::signal() {
    sem_post(&sem);
}
