// include/semaphore_wrapper.h
#pragma once

#include <semaphore.h>
#include <stdexcept>
#include <string>

class Semaphore {
public:
    Semaphore(unsigned int initial_count);
    ~Semaphore();

    void wait();
    void signal();

private:
    sem_t sem;
};


