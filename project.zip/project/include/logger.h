// include/logger.h
#pragma once

#include <mutex>
#include <string>
#include <iostream>

class Logger {
public:
    static void log(const std::string& message);

private:
    static std::mutex log_mutex;
};
