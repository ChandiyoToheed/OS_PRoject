// include/reservation_system.h
#pragma once

#include <vector>
#include <thread>
#include <memory>
#include "flight.h"
#include "semaphore_wrapper.h"

class ReservationSystem {
public:
    ReservationSystem(int flight_count, int seats_per_flight);
    void simulate(int user_threads);
    void bookTicket();
    void viewAvailableFlights();
    void cancelTicket();
    void rebookTicket();
    const std::vector<std::unique_ptr<Flight>>& getFlights() const { return flights; }
private:
    std::vector<std::unique_ptr<Flight>> flights;
    std::vector<std::thread> threads;
    std::vector<std::unique_ptr<Semaphore>> semaphores;

    void booking_worker(int thread_id);
};