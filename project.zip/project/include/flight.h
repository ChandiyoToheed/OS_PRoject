// include/flight.h
#pragma once

#include <vector>
#include <mutex>
#include <string>
#include <set>

class Flight {
public:
    Flight(const std::string& flight_id, int seat_count);

    bool book_seat(int& seat_number);
    bool cancel_seat(int seat_number);
    int available_seats() const;
    std::string get_flight_id() const;
    int get_most_recent_booked_seat();  // Non-const to allow modification of bookings

private:
    std::string flight_id;
    std::vector<bool> seats;
    mutable std::mutex seat_mutex;
    std::set<int> active_bookings;  // Track active bookings for cancellation
};