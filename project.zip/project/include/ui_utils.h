#pragma once

#include <iostream>
#include <string>
#include <thread>
#include <chrono>
#include <vector>

class UIUtils {
public:
    // Clear the console screen (cross-platform)
    static void clearScreen();
    
    // Display a loading animation for specified duration
    static void showLoadingAnimation(int milliseconds = 1000);
    
    // Display text with typing effect
    static void typeText(const std::string& text, int delayMilliseconds = 30);
    
    // Display ASCII art for program logo
    static void displayLogo();
    
    // Display airplane ASCII art
    static void displayAirplane();
    
    // Display ASCII art for booking success
    static void displayBookingSuccess();
    
    // Display ASCII art for booking cancelled
    static void displayBookingCancelled();
    
    // Add color formatting to text (ANSI escape codes)
    static std::string colorText(const std::string& text, const std::string& colorCode);
    
    // Common color codes
    static const std::string COLOR_RESET;
    static const std::string COLOR_RED;
    static const std::string COLOR_GREEN;
    static const std::string COLOR_YELLOW;
    static const std::string COLOR_BLUE;
    static const std::string COLOR_MAGENTA;
    static const std::string COLOR_CYAN;
    static const std::string COLOR_WHITE;
    
    // Create a fancy box around text
    static void displayBoxedText(const std::string& text);
    
    // Wait for user to press enter
    static void waitForEnter(const std::string& message = "Press Enter to continue...");
};